from flask import Blueprint, request
from flask import jsonify
from . import db_session
from .users import User

blueprint = Blueprint(
    'users_api',
    __name__,
    template_folder='templates'
)


@blueprint.route('/api/users')
def get_users():
    db_sess = db_session.create_session()
    users = db_sess.query(User).all()
    return jsonify(
        {
            'users':
                [item.to_dict(only=(
                    'id', 'surname', 'name', 'age', 'position', 'speciality', 'address', "city_from",
                    "email", 'modified_date',))
                    for item in users]
        }
    )


@blueprint.route('/api/users/<users_id>', methods=['GET'])
def get_one_users(users_id):
    db_sess = db_session.create_session()
    try:
        users = db_sess.query(User).get(int(users_id))
    except ValueError:
        return jsonify({'error': 'Not found'})
    if not users:
        return jsonify({'error': 'Not found'})
    return jsonify(
        {
            'users': users.to_dict(only=(
                'id', 'surname', 'name', 'age', 'position', 'speciality', 'address', "email",
                "city_from",
                'modified_date'))
        }
    )


@blueprint.route('/api/users', methods=['POST'])
def create_users():
    if not request.json:
        return jsonify({'error': 'Empty request'})
    elif not all(key in request.json for key in
                 ['id', 'surname', 'name', 'age', 'position', 'speciality', 'address', "city_from",
                  "email", "password"]):
        return jsonify({'error': 'Bad request'})
    db_sess = db_session.create_session()
    if db_sess.query(User).get(request.json['id']):
        return jsonify({'error': 'Id already exists'})
    users = User(
        id=request.json['id'],
        surname=request.json['surname'],
        name=request.json['name'],
        age=request.json['age'],
        position=request.json['position'],
        speciality=request.json['speciality'],
        address=request.json['address'],
        city_from=request.json['city_from'],
        email=request.json['email'],
    )
    users.set_password(request.json["password"])
    db_sess.add(users)
    db_sess.commit()
    return jsonify({'success': 'OK'})


@blueprint.route('/api/users/<users_id>', methods=['DELETE'])
def delete_users(users_id):
    db_sess = db_session.create_session()
    try:
        users = db_sess.query(User).get(int(users_id))
    except ValueError:
        return jsonify({'error': 'Not found'})
    if not users:
        return jsonify({'error': 'Not found'})
    db_sess.delete(users)
    db_sess.commit()
    return jsonify({'success': 'OK'})


@blueprint.route('/api/users', methods=['PUT'])
def edit_users():
    if not request.json:
        return jsonify({'error': 'Empty request'})
    db_sess = db_session.create_session()
    try:
        user = db_sess.query(User).get(request.json['id'])
    except KeyError:
        return jsonify({'error': 'Need a user id for editing'})
    if not user:
        return jsonify({'error': 'Id doesnt exists'})
    user.surname = request.json.get('surname', user.surname)
    user.name = request.json.get('name', user.name)
    user.age = request.json.get('age', user.age)
    user.position = request.json.get('position', user.position)
    user.speciality = request.json.get('speciality', user.speciality)
    user.address = request.json.get('address', user.address)
    user.city_from = request.json.get('city_from', user.city_from)
    user.email = request.json.get('email', user.email)
    db_sess.commit()
    return jsonify({'success': 'OK'})
