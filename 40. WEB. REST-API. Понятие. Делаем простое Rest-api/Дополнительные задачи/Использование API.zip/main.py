from flask import Flask, render_template, redirect, make_response, session, request, abort, jsonify
from data import db_session, jobs_api, user_api
from data.users import User
from data.department import Department
from forms.user import RegisterForm
from flask_login import LoginManager, login_user, logout_user, login_required, current_user
from forms.login_form import LoginForm
from forms.jobs import JobsForm
from forms.department import DepartmentForm
from data.jobs import Jobs
import datetime
import requests
from PIL import Image
from io import BytesIO
from parameters import get_parameters

app = Flask(__name__)
app.config['SECRET_KEY'] = 'yandexlyceum_secret_key'
app.config['PERMANENT_SESSION_LIFETIME'] = datetime.timedelta(
    days=365
)

login_manager = LoginManager()
login_manager.init_app(app)


@login_manager.user_loader
def load_user(user_id):
    db_sess = db_session.create_session()
    return db_sess.query(User).get(user_id)


@app.route("/")
def index():
    db_sess = db_session.create_session()
    jobs = db_sess.query(Jobs).all()
    users = db_sess.query(User).all()
    return render_template("index.html", jobs=jobs, users=users)


@app.route('/register', methods=['GET', 'POST'])
def reqister():
    form = RegisterForm()
    if form.validate_on_submit():
        if form.password.data != form.password_again.data:
            return render_template('register.html', title='Регистрация',
                                   form=form,
                                   message="Пароли не совпадают")
        db_sess = db_session.create_session()
        if db_sess.query(User).filter(User.email == form.login_email.data).first():
            return render_template('register.html', title='Регистрация',
                                   form=form,
                                   message="Такой пользователь уже есть")
        user = User(
            email=form.login_email.data,
            surname=form.surname.data,
            name=form.name.data,
            age=form.age.data,
            position=form.position.data,
            speciality=form.speciality.data,
            address=form.address.data,
            city_from=form.city_from.data
        )
        user.set_password(form.password.data)
        db_sess.add(user)
        db_sess.commit()
        return redirect('/login')
    return render_template('register.html', title='Регистрация', form=form)


@app.route("/session_test")
def session_test():
    visits_count = session.get('visits_count', 0)
    session['visits_count'] = visits_count + 1
    return make_response(
        f"Вы пришли на эту страницу {visits_count + 1} раз")


@app.route('/login', methods=['GET', 'POST'])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        db_sess = db_session.create_session()
        user = db_sess.query(User).filter(User.email == form.email.data).first()
        if user and user.check_password(form.password.data):
            login_user(user, remember=form.remember_me.data)
            return redirect("/")
        return render_template('login.html',
                               message="Неправильный логин или пароль",
                               form=form)
    return render_template('login.html', title='Авторизация', form=form)


@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect("/")


@app.route('/jobs', methods=['GET', 'POST'])
@login_required
def add_job():
    form = JobsForm()
    if form.validate_on_submit():
        db_sess = db_session.create_session()
        jobs = Jobs()
        jobs.job = form.title.data
        jobs.team_leader = form.team_leader.data
        jobs.work_size = form.work_size.data
        jobs.collaborators = form.collaborators.data
        jobs.is_finished = form.is_finished.data
        jobs.creator = current_user.id
        db_sess.merge(current_user)
        db_sess.add(jobs)
        db_sess.commit()
        return redirect('/')
    return render_template('jobs.html', title='Добавление работы',
                           form=form)


@app.route('/job_edit/<int:id>', methods=['GET', 'POST'])
@login_required
def edit_jobs(id):
    db_sess = db_session.create_session()
    job = db_sess.query(Jobs).filter(Jobs.id == id).first()
    if current_user.id == 1 or current_user.id == job.creator:
        form = JobsForm()
        if request.method == "GET":
            jobs = db_sess.query(Jobs).filter(Jobs.id == id).first()
            if jobs:
                form.title.data = jobs.job
                form.team_leader.data = jobs.team_leader
                form.work_size.data = jobs.work_size
                form.collaborators.data = jobs.collaborators
                form.is_finished.data = jobs.is_finished
            else:
                abort(404)
        if form.validate_on_submit():
            jobs = db_sess.query(Jobs).filter(Jobs.id == id).first()
            if jobs:
                jobs.job = form.title.data
                jobs.team_leader = form.team_leader.data
                jobs.work_size = form.work_size.data
                jobs.collaborators = form.collaborators.data
                jobs.is_finished = form.is_finished.data
                db_sess.commit()
                return redirect('/')
            else:
                abort(404)
        return render_template('jobs.html',
                               title='Редактирование работы',
                               form=form)
    abort(404)


@app.route('/job_delete/<int:id>', methods=['GET', 'POST'])
@login_required
def delete_jobs(id):
    db_sess = db_session.create_session()
    job = db_sess.query(Jobs).filter(Jobs.id == id).first()
    if current_user.id == 1 or current_user.id == job.creator:
        db_sess.delete(job)
        db_sess.commit()
        return redirect('/')
    abort(404)


@app.route("/departments")
def departments():
    db_sess = db_session.create_session()
    departments = db_sess.query(Department).all()
    users = db_sess.query(User).all()
    return render_template("departments.html", departments=departments, users=users)


@app.route('/add_department', methods=['GET', 'POST'])
@login_required
def add_department():
    form = DepartmentForm()
    if form.validate_on_submit():
        db_sess = db_session.create_session()
        department = Department()
        department.title = form.title.data
        department.chief = form.chief.data
        department.members = form.members.data
        department.email = form.email.data
        department.creator = current_user.id
        db_sess.merge(current_user)
        db_sess.add(department)
        db_sess.commit()
        return redirect('/departments')
    return render_template('add_department.html', title='Add department',
                           form=form)


@app.route('/department_edit/<int:id>', methods=['GET', 'POST'])
@login_required
def edit_departments(id):
    db_sess = db_session.create_session()
    department = db_sess.query(Department).filter(Department.id == id).first()
    if current_user.id == 1 or current_user.id == department.creator:
        form = DepartmentForm()
        if request.method == "GET":
            departments = db_sess.query(Department).filter(Department.id == id).first()
            if departments:
                form.title.data = department.title
                form.chief.data = department.chief
                form.members.data = department.members
                form.email.data = department.email
            else:
                abort(404)
        if form.validate_on_submit():
            departments = db_sess.query(Department).filter(Department.id == id).first()
            if departments:
                department.title = form.title.data
                department.chief = form.chief.data
                department.members = form.members.data
                department.email = form.email.data
                db_sess.commit()
                return redirect('/departments')
            else:
                abort(404)
        return render_template('add_department.html',
                               title='Edit department',
                               form=form)
    abort(404)


@app.route('/department_delete/<int:id>', methods=['GET', 'POST'])
@login_required
def delete_departments(id):
    db_sess = db_session.create_session()
    department = db_sess.query(Department).filter(Department.id == id).first()
    if department:
        if current_user.id == 1 or current_user.id == department.creator:
            db_sess.delete(department)
            db_sess.commit()
            return redirect('/departments')
    abort(404)


@app.route('/users_show/<int:user_id>')
@login_required
def users_show(user_id):
    response = requests.get(f'http://localhost:5000/api/users/{user_id}').json()
    if "error" in response.keys():
        abort(404)
    city = response["users"]["city_from"]
    name = response["users"]["name"] + " " + response["users"]["surname"]
    geocoder_params = {
        "apikey": "40d1649f-0493-4b70-98ba-98533de7710b",
        "geocode": city,
        "format": "json"}
    geocoder_api_server = "http://geocode-maps.yandex.ru/1.x/"
    response = requests.get(geocoder_api_server, params=geocoder_params)
    Image.open(BytesIO(get_parameters(response).content)).convert('RGB').save(
        f'static/img/{city}.jpeg')
    return render_template("user_show.html", city=city, name=name)


@app.errorhandler(404)
def not_found(error):
    return make_response(jsonify({'error': 'Not found'}), 404)


def main():
    db_session.global_init("db/data.db")
    app.register_blueprint(jobs_api.blueprint)
    app.register_blueprint(user_api.blueprint)
    app.run()


if __name__ == '__main__':
    main()
