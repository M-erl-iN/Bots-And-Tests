import vk_api
from vk_api.bot_longpoll import VkBotLongPoll, VkBotEventType
import random
from parameters import get_parameters
import requests
import json
from io import BytesIO

TOKEN = TOKEN
group_id = "203303842"


#  LongPoll API == API 5.103


def main():
    vk_session = vk_api.VkApi(
        token=TOKEN)

    keyboard = {
        "one_time": True,
        "buttons": [[
            get_button(label="Спутник", color="positive"),
            get_button(label="Карта", color="positive")
        ]]
    }
    keyboard = json.dumps(keyboard, ensure_ascii=False).encode("utf-8")
    keyboard = str(keyboard.decode("utf-8"))

    first_message = False
    show_keyboard = False

    longpoll = VkBotLongPoll(vk_session, group_id)

    for event in longpoll.listen():

        if event.type == VkBotEventType.MESSAGE_NEW:
            vk = vk_session.get_api()
            if not first_message:
                message = f"Какую местность вы хотите увидеть?"
                first_message = True
                show_keyboard = True
                vk.messages.send(user_id=event.obj.message['from_id'],
                                 message=message,
                                 random_id=random.randint(0, 2 ** 64))
            else:
                if show_keyboard:
                    geocode = event.obj.message['text']
                    show_keyboard = False
                    message = "Выберите тип фотографии"
                    vk.messages.send(user_id=event.obj.message['from_id'],
                                     message=message,
                                     random_id=random.randint(0, 2 ** 64), keyboard=keyboard)
                else:
                    map_type = event.obj.message['text'].lower()
                    if map_type == "спутник":
                        img = get_img(geocode, "sat")
                    elif map_type == "карта":
                        img = get_img(geocode, "map")
                    else:
                        message = f"Неправильный тип фотографии, введите заново: "
                        vk.messages.send(user_id=event.obj.message['from_id'],
                                         message=message,
                                         random_id=random.randint(0, 2 ** 64), keyboard=keyboard)
                        continue

                    upload = vk_api.VkUpload(vk_session)
                    response = upload.photo_messages(img)[0]

                    owner_id = response['owner_id']
                    photo_id = response['id']
                    attachment = f'photo{owner_id}_{photo_id}'
                    message = f"Это {geocode}. Что вы еще хотите увидеть?"
                    vk.messages.send(user_id=event.obj.message['from_id'],
                                     message=message,
                                     random_id=random.randint(0, 2 ** 64), attachment=attachment)
                    show_keyboard = True


def get_img(geocode, map_type):
    geocoder_params = {
        "apikey": "40d1649f-0493-4b70-98ba-98533de7710b",
        "geocode": geocode,
        "format": "json"}
    geocoder_api_server = "http://geocode-maps.yandex.ru/1.x/"
    response = requests.get(geocoder_api_server, params=geocoder_params)
    img = BytesIO(get_parameters(response, map_type).content)
    return img


def get_button(label, color, payload=""):
    return {
        "action": {
            "type": "text",
            "payload": json.dumps(payload),
            "label": label
        },
        "color": color
    }


if __name__ == '__main__':
    main()
